
#pahle screen banai and usme colour title fill kiya
from turtle import Turtle, Screen
from snake import Snake
import time
screen= Screen()
screen.setup(width= 600, height= 600)
screen.bgcolor("black")
screen.title("Snake game")
screen.tracer(0)
#ab body banana h snake ka to


# snake1 = snake.shape("square"). galti approch sahi h but coordinate oo hota h middle ka and abki sabka apna turtle banao
# snake.goto(170,100)
# snake.forward(1)
# snake.color("white")
# snake2= snake.shape("square")
# snake.goto(190,100)
# snake.forward(1)
# snake.color("white")
# snake3= snake.shape("square")
# snake.goto(210,100)
# snake.forward(1)
# snake.color("white")
##method 1
# def snake_body():
#     segment1 = Turtle("square")
#     segment1.color("red")
#     segment1.goto(-20,0)
#
#     segment2 = Turtle("square")
#     segment2.color("red")
#     segment2.goto(0,0)
#
#     segment3 = Turtle("square")
#     segment3.color("red")
#     segment3.goto(20,0)
# snake_body()
snake = Snake()
# starting_positions = [(0, 0), (-20, 0), (-40, 0)]
#
# segments=[]

# for position in starting_positions:
#     new_segment =Turtle("square")
#     new_segment.color("white")
#     new_segment.penup()
#     new_segment.goto(position)
#     segments.append(new_segment)


# screen.listen()
# screen.onkey(snake.up, "up")
# screen.onkey(snake.down, "down")
# screen.onkey(snake.left, "left")
# screen.onkey(snake.right, "right")

game_is_on = True
while game_is_on:
    screen.update()
    time.sleep(0.1)

    snake.move()


    #
    # for seg_movement in range(len(segments)-1, 0, -1):
    #         new_x = segments[seg_movement-1].xcor()
    #         new_y = segments[seg_movement-1].ycor()
    #         segments[seg_movement].goto(new_x, new_y)
    # segments[0].forward(20)
    # #segments[0].left(90)
screen.exitonclick()
