from turtle import Turtle
# screen= Screen()
# screen.setup(width= 600, height= 600)
# screen.bgcolor("black")
# screen.title("Snake game")
# screen.tracer(0)
STARTING_POSITION = [(0, 0), (-20, 0), (-40, 0)]
MOVE_DISTANCE = 20

class Snake:

    def __int__(self):
        self.segments = []
        self.create_snake()

    def create_snake(self):
        for position in STARTING_POSITION:
            new_segment = Turtle("square")
            new_segment.color("white")
            new_segment.penup()
            new_segment.goto(position)
            self.segments.append(new_segment)
            #new_segment.showturtle()
            # print(len(segments))
    # create_snake()

    def move(self):
        for seg_movement in range(len(self.segments)-1, 0, -1):
            new_x = self.segments[seg_movement-1].xcor()
            new_y = self.segments[seg_movement-1].ycor()
            self.segments[seg_movement].goto(new_x, new_y)
        self.segments[0].forward(MOVE_DISTANCE)
    #
    # def up(self):
    #     for move_up in range

